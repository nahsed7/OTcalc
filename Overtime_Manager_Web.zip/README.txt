LABOUR OVERTIME MANAGER — WEB EDITION

Open index.html in Chrome or Edge. No Python or local server is required. Internet is required on first load for the Excel (SheetJS) and OCR (Tesseract.js) libraries.

Data is saved in this browser profile using localStorage. Use Export backup JSON regularly, especially before clearing browser data or changing computers. To move data to another browser/computer, export JSON on the old device and Restore backup JSON on the new one.

For GitHub Pages: create a repository, upload index.html to the repository root, then enable Settings > Pages > Deploy from a branch > main / root.

Scanner note: image OCR is best-effort. It recognises printed rows containing a date/time and C/In or C/Out, then pairs first In with last Out for each date. Always review scanned times before Calculate & Save. Excel requires Time and State columns.
